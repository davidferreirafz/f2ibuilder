#!/bin/sh
export CLASSPATH=.:$CLASSPATH:$JAVA_HOME 
java -jar F2IBuilder.jar